---
Published : false
Author: Ceyhan
Description: Customer Dataview Test
---



```dataview
TABLE Author, Description
FROM "Data"
WHERE Author = "Ceyhan"
```
