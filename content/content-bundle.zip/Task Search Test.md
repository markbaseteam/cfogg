---
Published : false
Author: Ceyhan
Description: Task Search Test
---

```dataview
TABLE info
WHERE info = "Ceyhan"
```

- [ ] Task 1
- [ ] Task 2